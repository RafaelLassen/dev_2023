<?php
 include './db.class.php';

//include "./paginas/cabecalho.inc.php";
//include "./paginas/menu.inc.php";
//include "./paginas/conteudo.inc.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
  <h3>Bem vindo ao sistema academico</h3>
  <a href="paginas/AlunoList.php">Aluno</a><br>


<?php
  include "./paginas/rodape.inc.php";
?>
</body>
</html>